# Graylog 재현 설정

이 설정은 2026-11-09에 실행 중인 Graylog 6.1.16 API에서 읽어 만든 NEXUS 전용 스냅샷입니다.

포함 범위:
- 현재 Input 3개: 포털 GELF UDP, Wazuh JSON UDP, pfSense Syslog UDP
- NEXUS_AUTH / NEXUS_AI_SECURITY / NEXUS_WEB Stream 3개
- `[NEXUS]` Event Definition 13개: OBS 관찰 1개와 R1~R12
- 알림 연결표 12개

이벤트 정의의 서버 내부 ID와 알림 인증 정보는 포함하지 않았습니다. 알림은 `notification-map.json`을 참고해 대상 PC의 n8n 주소와 자격 증명을 다시 설정하고 각 Event Definition에 연결해야 합니다.

## 적용

1. 대상 Graylog가 입력 포트(12201/UDP, 5140/UDP, 1514/UDP)를 사용할 수 있는지 확인합니다.
2. Graylog API 토큰을 대상 PC에서 `GRAYLOG_API_TOKEN` 환경변수로 설정합니다. 토큰은 파일에 저장하지 않습니다.
3. 이 폴더의 `import_graylog.ps1`을 먼저 `-DryRun`으로 실행해 생성/충돌 계획을 확인합니다.
4. 깨끗한 대상 Graylog에서만 `-Apply`를 실행합니다. 동일 이름의 설정이 다른 경우 importer는 덮어쓰지 않고 충돌로 보고합니다.
5. `notification-map.json` 기준으로 NEXUS webhook 알림을 만들고 Event Definition에 연결합니다. 인증 값은 대상 n8n의 credential에 맞춰 별도 등록합니다.

예시 명령은 상위 README를 참고하세요. 기존 Graylog 입력/Stream/Event Definition을 삭제하거나 수정하지 않습니다.