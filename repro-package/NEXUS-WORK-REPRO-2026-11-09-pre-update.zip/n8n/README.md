# n8n v3 로컬 전환 및 재현

## 이 PC의 활성 workflow

- 이름: NEXUS 탐지 알림 수신 v3 - AI-XDR 통합본 (DRY-RUN)
- ID: NXv3AiXdr27Qp6Lm
- n8n: 2.37.7
- 현재 상태: Active / Published
- production webhook 및 workflow ID를 유지한 채 로컬 대상만 연결했습니다.

활성 workflow의 Ticket DB 처리 노드 8개는 별도 복제 DB credential을 사용합니다. AI-XDR 내부 API 노드들은 n8n 컨테이너에서 접근 가능한 host.docker.internal:5070의 Flask 앱을 호출합니다. 로컬 MySQL은 host.docker.internal:3308로 연결합니다. 운영 원본 DB와 기존 credential은 덮어쓰지 않았습니다.

AI-XDR 평가 후 Discord 분기는 현재 게시된 workflow에서 강제로 닫혀 있습니다. dry-run으로 유지되며 실제 차단이나 계정 잠금은 활성화하지 않았습니다. 재현 템플릿은 비활성이고 credential, webhook ID, static data, 실행 이력을 포함하지 않습니다.

## 재현용 credential 설정

템플릿을 별도 PC의 별도 n8n 인스턴스에 inactive로 import한 뒤 새 credential을 등록하고 노드에 연결합니다. credential 표시 이름은 대상 인스턴스에서 임의로 정해도 됩니다.

| 용도 | credential | 필요한 노드 |
|---|---|---|
| Ticket DB | MySQL credential, host.docker.internal:3308 / DB nexus / user nexus_n8n_local | README의 8개 Ticket/rate-limit 노드 |
| 내부 AI-XDR API | HTTP Bearer Auth, 대상 포털의 LAB_INTERNAL_API_TOKEN | 이벤트 수집, process, decision 및 차단 API 노드 |
| 수신 및 Ticket 관리 webhook | HTTP Header Auth, 대상 n8n에서 설정한 header name/value | Webhook, 상황판 조회(GET), 티켓 처리 요청(POST) |
| Discord | Discord webhook credential | 필요할 때만 연결. 평가 후 Discord branch는 명시적으로 검토·승인하기 전까지 닫아 둠 |

credential 값이나 API key는 export/문서에 저장하지 않습니다. .env에서 새 로컬 비밀번호와 토큰을 만들고, n8n credential UI에 직접 입력합니다.

## MySQL 권한

새 로컬 복제 DB에만 n8n 전용 계정을 만듭니다. local-ticket-db-grants.sql.example은 다음 세 테이블에만 SELECT/INSERT/UPDATE 권한을 줍니다.

- security_incident_tickets
- security_incident_alerts
- security_discord_rate_limit

현재 복제 DB에서 이 테이블들이 확인됐습니다. 원본/운영 DB에 이 예시를 실행하지 않습니다. DROP, DELETE, DDL, 전역 권한은 부여하지 않습니다.

## 별도 PC 적용 순서

1. 격리된 MySQL 복제본을 준비하고 schema와 필요한 데이터만 가져옵니다. 패키지에는 DB dump가 없습니다.
2. 대상 환경의 포털 주소, MySQL host/port, 내부 API token을 준비합니다. MySQL은 loopback 또는 내부 전용 네트워크에만 공개합니다.
3. 전용 DB 계정을 만들고 table-level grants를 적용합니다.
4. 템플릿을 import하되 inactive 상태로 둡니다.
5. 새 MySQL, Bearer Auth, Header Auth credential을 생성해 해당 노드에 연결합니다. 외부 알림을 사용할 계획이 없으면 Discord credential을 등록하거나 branch를 열지 않습니다.
6. API URL과 workflow 경로를 검토하고 무해한 테스트 이벤트로 확인합니다. 자동 차단과 계정 조치는 비활성 상태를 유지합니다.
7. 대상 workflow가 기존 활성 workflow와 중복되지 않는 것을 확인한 뒤에만 activate/publish합니다.

## 로컬 확인 결과

- local R8 synthetic 경보가 Graylog에 생성됨.
- n8n 실행 #4409에서 Ticket NX-DB-000365와 /events accepted=true 확인.
- 실행 #4410에서 /process processed=1, assessment ca054404-d842-4766-a270-b3f5f03d62a2 생성 확인.
- 결과는 BENIGN / score 10 / confidence 0.80 / NO_ACTION.
- IP 차단과 계정 잠금은 실행되지 않음.
- 평가 후 Discord 분기는 검증 과정에서 한 번 실행된 것이 확인되어 게시된 workflow에서 즉시 강제 OFF 했습니다. 이후 재현과 운영 시 gate가 다시 열리지 않는지 확인하세요.
